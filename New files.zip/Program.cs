using System;

namespace ExcelSplitter
{
    class Program
    {
        static int Main(string[] args)
        {
            string exeDir = AppContext.BaseDirectory;

            using var bootstrapLogger = new Logger(exeDir);
            var config = AppConfig.LoadOrCreate(exeDir, bootstrapLogger);

            // If LogFolder is configured to a different path, a second logger is created there.
            string logFolder = string.IsNullOrWhiteSpace(config.LogFolder) ? exeDir : config.LogFolder;
            Logger logger = logFolder == exeDir ? bootstrapLogger : new Logger(logFolder);

            try
            {
                if (args.Length == 0)
                {
                    logger.Error("No file specified. Drag and drop Excel file(s) (.xls or .xlsx) onto the program, or pass the path as an argument.");
                    WaitForExit();
                    return 1;
                }

                var processor = new ExcelProcessor(config, logger);
                int successCount = 0, failCount = 0;

                foreach (var inputPath in args)
                {
                    logger.Info($"====== Starting to process file: {inputPath} ======");
                    var result = processor.ProcessFile(inputPath);

                    if (result.Success)
                    {
                        logger.Success($"Output file saved: {result.OutputPath} (total rows split: {result.TotalSplitRows})");
                        successCount++;
                    }
                    else
                    {
                        logger.Error($"Processing '{inputPath}' failed: {result.ErrorMessage}");
                        failCount++;
                    }
                }

                logger.Info($"Done. Succeeded: {successCount} | Failed: {failCount}");
                logger.Info($"Full log file: {logger.LogFilePath}");

                WaitForExit();
                return failCount == 0 ? 0 : 2;
            }
            finally
            {
                if (!ReferenceEquals(logger, bootstrapLogger))
                    logger.Dispose();
            }
        }

        private static void WaitForExit()
        {
            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }
    }
}
